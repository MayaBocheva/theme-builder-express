import V1 from '../imports/V1';

export default function App() {
  return (
    <div className="min-h-screen w-full">
      <V1 />
    </div>
  );
}
