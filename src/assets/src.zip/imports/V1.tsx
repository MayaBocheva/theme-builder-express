import svgPaths from "./svg-cwk1rxxlq0";
import clsx from "clsx";
import imgRectangle1446 from "figma:asset/85c9a8eb7df11a24de0249bad074c0c0b89961e1.png";
import imgRectangle1447 from "figma:asset/df9641a775c42a1bfae55c438ad76f8737e21345.png";
type Wrapper9Props = {
  additionalClassNames?: string;
};

function Wrapper9({ children, additionalClassNames = "" }: React.PropsWithChildren<Wrapper9Props>) {
  return (
    <div style={{ "--transform-inner-width": "0", "--transform-inner-height": "0" } as React.CSSProperties} className={clsx("flex items-center justify-center relative shrink-0", additionalClassNames)}>
      {children}
    </div>
  );
}

function Wrapper8({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] min-w-full not-italic relative shrink-0 text-[#372420] text-[12px] w-[min-content]">{children}</p>
      <Text6 text="John H." />
    </div>
  );
}

function Wrapper7({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#372420] text-[16px] text-nowrap">{children}</p>
    </div>
  );
}
type Wrapper6Props = {
  additionalClassNames?: string;
};

function Wrapper6({ children, additionalClassNames = "" }: React.PropsWithChildren<Wrapper6Props>) {
  return (
    <div className={clsx("relative rounded-[20px]", additionalClassNames)}>
      <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[20px]">{children}</div>
    </div>
  );
}

function Wrapper5({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="bg-white content-stretch flex items-center justify-center px-[8px] py-[4px] relative shrink-0">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] not-italic relative shrink-0 text-[#372420] text-[11px] text-center text-nowrap tracking-[2px] uppercase">{children}</p>
    </div>
  );
}
type Wrapper4Props = {
  additionalClassNames?: string;
};

function Wrapper4({ children, additionalClassNames = "" }: React.PropsWithChildren<Wrapper4Props>) {
  return (
    <div className={clsx("content-stretch flex gap-[8px] items-center relative shrink-0", additionalClassNames)}>
      <CheckSmall />
      <p className="font-['Inter:Bold',sans-serif] font-bold leading-[normal] not-italic relative shrink-0 text-[#73374c] text-[12px] text-nowrap">{children}</p>
    </div>
  );
}

function Wrapper3({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="bg-[#e7ded8] content-stretch flex items-center p-[16px] relative rounded-[8px] shrink-0 w-[850px]">
      <p className="basis-0 font-['Inter:Medium',sans-serif] font-medium grow leading-[normal] min-h-px min-w-px not-italic relative shrink-0 text-[#372420] text-[16px]">{children}</p>
      <Helper5 />
    </div>
  );
}

function Wrapper2({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="[text-decoration-skip-ink:none] [text-underline-position:from-font] decoration-solid font-['Inter:Bold',sans-serif] font-bold leading-[28px] not-italic relative shrink-0 text-[#e7ded8] text-[14px] text-nowrap underline">{children}</p>
    </div>
  );
}
type Card11Props = {
  additionalClassNames?: string;
};

function Card11({ children, additionalClassNames = "" }: React.PropsWithChildren<Card11Props>) {
  return (
    <div className={clsx("relative rounded-[8px] shrink-0 w-full", additionalClassNames)}>
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center p-[16px] relative w-full">{children}</div>
      </div>
    </div>
  );
}
type Wrapper1Props = {
  additionalClassNames?: string;
};

function Wrapper1({ children, additionalClassNames = "" }: React.PropsWithChildren<Wrapper1Props>) {
  return (
    <div className={clsx("relative shrink-0 w-full", additionalClassNames)}>
      <div className="flex flex-col items-center size-full">
        <div className="content-stretch flex flex-col gap-[24px] items-center pb-[8px] pt-[24px] px-[100px] relative w-full">{children}</div>
      </div>
    </div>
  );
}
type WrapperProps = {
  additionalClassNames?: string;
};

function Wrapper({ children, additionalClassNames = "" }: React.PropsWithChildren<WrapperProps>) {
  return (
    <div className={clsx("flex-none", additionalClassNames)}>
      <div className="h-0 relative w-[200px]">
        <div className="absolute inset-[-2.5px_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 200 5">
            {children}
          </svg>
        </div>
      </div>
    </div>
  );
}
type Text7Props = {
  text: string;
};

function Text7({ text }: Text7Props) {
  return <Wrapper2>{text}</Wrapper2>;
}
type Text6Props = {
  text: string;
};

function Text6({ text }: Text6Props) {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#372420] text-[12px] text-nowrap tracking-[2.4px] uppercase">{text}</p>
    </div>
  );
}

function Helper5() {
  return (
    <Wrapper9 additionalClassNames="size-[36px]">
      <div className="flex-none rotate-[90deg]">
        <BuildingBlocksTrailingElement />
      </div>
    </Wrapper9>
  );
}
type Text5Props = {
  text: string;
};

function Text5({ text }: Text5Props) {
  return <Wrapper3>{text}</Wrapper3>;
}

function BuildingBlocksTrailingElement() {
  return (
    <div className="relative size-[36px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="icon">
          <path d={svgPaths.p2aa100} fill="var(--fill-0, #E7DED8)" id="icon_2" />
        </g>
      </svg>
    </div>
  );
}

function Helper4() {
  return (
    <div className="h-[37px] relative shrink-0 w-[40px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 37">
        <g id="Frame 48095442">
          <rect fill="var(--fill-0, #73374C)" height="37" rx="8" width="40" />
          <g id="Subtract">
            <path d={svgPaths.p1c0a9900} fill="var(--fill-0, white)" />
            <path d={svgPaths.pb2aaa00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p3c631880} fill="var(--fill-0, white)" />
          </g>
        </g>
      </svg>
    </div>
  );
}
type Text4Props = {
  text: string;
};

function Text4({ text }: Text4Props) {
  return (
    <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] min-w-full not-italic relative shrink-0 text-[#73374c] text-[#e7ded8] text-[12px] w-[min-content]">
      <span className="font-['Inter:Bold',sans-serif] font-bold">{`Perfect for: `}</span>
      <span className="font-['Inter:Regular',sans-serif] font-normal">{text}</span>
    </p>
  );
}

function Helper3() {
  return <Wrapper4>{`Extended time for emotional processing and release `}</Wrapper4>;
}
type Text3Props = {
  text: string;
};

function Text3({ text }: Text3Props) {
  return <Wrapper4>{text}</Wrapper4>;
}

function CheckSmall() {
  return (
    <div className="relative shrink-0 size-[16px]">
      <div className="absolute inset-0" style={{ "--stroke-0": "rgba(152, 123, 136, 1)" } as React.CSSProperties}>
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
          <g id="check_small">
            <rect height="14" rx="7" stroke="var(--stroke-0, #987B88)" strokeWidth="2" width="14" x="1" y="1" />
            <path d={svgPaths.p21f23300} fill="var(--fill-0, #987B88)" id="icon" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Helper2() {
  return <p className="font-['Inter:Bold',sans-serif] font-bold min-w-full relative shrink-0 text-[#73374c] text-[12px] w-[min-content]">{`This is the complete Tantric healing experience sacred journey that honors your entire being with spaciousness and reverence. `}</p>;
}
type Helper1Props = {
  text: string;
  text1: string;
};

function Helper1({ text, text1 }: Helper1Props) {
  return (
    <div className="content-stretch flex flex-col font-['Inter:Medium',sans-serif] font-medium gap-[8px] items-start relative shrink-0 text-nowrap">
      <p className="relative shrink-0 text-[#73374c] text-[16px]">{text}</p>
      <p className="relative shrink-0 text-[#987b88] text-[12px] tracking-[2.4px] uppercase">{text1}</p>
    </div>
  );
}

function Icon1() {
  return (
    <div className="absolute left-1/2 size-[24px] top-1/2 translate-x-[-50%] translate-y-[-50%]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Icon" opacity="0">
          <g id="icon"></g>
        </g>
      </svg>
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[24px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p11722af0} fill="var(--fill-0, #A7567B)" id="icon" />
        </g>
      </svg>
    </div>
  );
}
type HelperProps = {
  text: string;
  text1: string;
};

function Helper({ text, text1 }: HelperProps) {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start justify-center leading-[normal] not-italic relative self-stretch shrink-0 text-[#372420] text-center w-[200px]">
      <p className="font-['Inter:Medium',sans-serif] font-medium relative shrink-0 text-[14px] w-full">{text}</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[12px] w-full">{text1}</p>
    </div>
  );
}

function Frame48095459Helper() {
  return (
    <Wrapper9 additionalClassNames="h-[0.493px] w-[199.999px]">
      <Wrapper additionalClassNames="rotate-[0.141deg]">
        <path d="M0 2.5H200" id="Vector 16" stroke="var(--stroke-0, #73374C)" strokeWidth="5" />
      </Wrapper>
    </Wrapper9>
  );
}
type Text2Props = {
  text: string;
  additionalClassNames?: string;
};

function Text2({ text, additionalClassNames = "" }: Text2Props) {
  return (
    <div className={clsx("bg-[#a7567b] content-stretch flex flex-col items-center justify-center relative rounded-[200px] shrink-0 w-[35px]", additionalClassNames)}>
      <p className="font-['Gabarito:Bold',sans-serif] font-bold leading-[normal] relative shrink-0 text-[16px] text-nowrap text-white">{text}</p>
    </div>
  );
}
type Text1Props = {
  text: string;
};

function Text1({ text }: Text1Props) {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0">
      <p className="[text-decoration-skip-ink:none] [text-underline-position:from-font] decoration-solid font-['Inter:Bold',sans-serif] font-bold leading-[28px] not-italic relative shrink-0 text-[#a7567b] text-[14px] text-nowrap underline">{text}</p>
    </div>
  );
}
type TagTextProps = {
  text: string;
};

function TagText({ text }: TagTextProps) {
  return <Wrapper5>{text}</Wrapper5>;
}
type TextProps = {
  text: string;
};

function Text({ text }: TextProps) {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0">
      <p className="font-['Inter:Bold',sans-serif] font-bold leading-[28px] not-italic relative shrink-0 text-[#e7ded8] text-[14px] text-nowrap">{text}</p>
    </div>
  );
}

function BsckgroundVector() {
  return (
    <div className="absolute h-[2703px] left-[-498px] top-[-254px] w-[2277px]" data-name="Bsckground vector">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2277 2703">
        <g id="Bsckground vector">
          <g id="Union">
            <path clipRule="evenodd" d={svgPaths.paea4780} fill="var(--fill-0, white)" fillOpacity="0.85" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p274b0e00} fill="var(--fill-0, white)" fillOpacity="0.85" fillRule="evenodd" />
          </g>
          <g id="Union_2">
            <path clipRule="evenodd" d={svgPaths.p53cdb00} fill="var(--fill-0, white)" fillOpacity="0.85" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p205faa80} fill="var(--fill-0, white)" fillOpacity="0.85" fillRule="evenodd" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex flex-col font-['Inter:Regular',sans-serif] font-normal gap-[2px] h-[38px] items-start justify-center leading-[normal] not-italic relative shrink-0 text-nowrap">
      <p className="relative shrink-0 text-[#a7567b] text-[14px] tracking-[5px]">SHANTI PATH</p>
      <p className="relative shrink-0 text-[#987b88] text-[12px]">Sacred Energy Body Work</p>
    </div>
  );
}

function Logo() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="logo">
      <div className="h-[40px] relative shrink-0 w-[46px]" data-name="Subtract">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(167, 86, 123, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 46 40">
            <g id="Subtract">
              <path d={svgPaths.p21c29100} fill="var(--fill-0, #A7567B)" />
              <path d={svgPaths.p54d2df1} fill="var(--fill-0, #A7567B)" />
              <path d={svgPaths.p372bff00} fill="var(--fill-0, #A7567B)" />
            </g>
          </svg>
        </div>
      </div>
      <Frame1 />
    </div>
  );
}

function Logo1() {
  return (
    <div className="content-stretch flex items-center relative shrink-0" data-name="Logo">
      <Logo />
    </div>
  );
}

function EvaArrowIosBackOutline() {
  return (
    <div className="relative size-[18px]" data-name="eva:arrow-ios-back-outline">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="eva:arrow-ios-back-outline">
          <path d={svgPaths.p3757dc80} fill="var(--fill-0, #A7567B)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#a7567b] text-[18px] text-nowrap">Offerings</p>
      <Wrapper9 additionalClassNames="size-[18px]">
        <div className="flex-none rotate-[270deg] scale-y-[-100%]">
          <EvaArrowIosBackOutline />
        </div>
      </Wrapper9>
    </div>
  );
}

function Menu() {
  return (
    <div className="content-stretch flex gap-[64px] items-center justify-end relative shrink-0" data-name="menu">
      <Frame />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#a7567b] text-[18px] text-nowrap">About Me</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#a7567b] text-[18px] text-nowrap">{`F&Q`}</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#a7567b] text-[18px] text-nowrap">Contact</p>
    </div>
  );
}

function Frame28() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start justify-center relative shrink-0">
      <Text text="Request an interview" />
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#a7567b] content-stretch flex flex-col gap-[8px] h-[48px] items-center justify-center overflow-clip px-[24px] py-[8px] relative rounded-[4px] shrink-0" data-name="Button 1">
      <div className="absolute bg-[#a7567b] inset-0 rounded-[7.2px]" data-name="Rectangle" />
      <Frame28 />
    </div>
  );
}

function Navigation() {
  return (
    <div className="bg-[#f6efeb] content-stretch flex h-[78px] items-center justify-between pb-[8px] pt-[24px] px-[100px] relative shrink-0 w-[1440px]" data-name="Navigation">
      <Logo1 />
      <Menu />
      <Button />
    </div>
  );
}

function Frame31() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start justify-center relative shrink-0">
      <Text text="Request an interview" />
    </div>
  );
}

function Button2() {
  return (
    <div className="bg-[#a7567b] content-stretch flex flex-col gap-[8px] h-[48px] items-center justify-center overflow-clip px-[24px] py-[8px] relative rounded-[4px] shrink-0" data-name="Button 3">
      <div className="absolute bg-[#a7567b] inset-0 rounded-[7.2px]" data-name="Rectangle" />
      <Frame31 />
    </div>
  );
}

function Frame32() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0">
      <Text1 text="Why I need an interview" />
    </div>
  );
}

function Button3() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[16px] py-[8px] relative rounded-[4px] shrink-0" data-name="Button 4">
      <Frame32 />
    </div>
  );
}

function Frame29() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0">
      <Button2 />
      <Button3 />
    </div>
  );
}

function Frame3() {
  return (
    <div className="h-[25px] relative shrink-0 w-[45px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 45 25">
        <g id="Frame 48095444">
          <circle cx="12.5" cy="12.5" fill="var(--fill-0, #A7567B)" id="Ellipse 1135" r="12" stroke="var(--stroke-0, white)" />
          <circle cx="22.5" cy="12.5" fill="var(--fill-0, #A76933)" id="Ellipse 1136" r="12" stroke="var(--stroke-0, white)" />
          <circle cx="32.5" cy="12.5" fill="var(--fill-0, #412722)" id="Ellipse 1137" r="12" stroke="var(--stroke-0, white)" />
        </g>
      </svg>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0 w-full">
      <Frame3 />
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] not-italic relative shrink-0 text-[#73374c] text-[10px] text-nowrap">50+clients have started the transformation</p>
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-[468px]">
      <TagText text="Awaken Your True Essence" />
      <div className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] min-w-full not-italic relative shrink-0 text-[#372420] text-[40px] w-[min-content]">
        <p className="mb-0">{`Your sacred journey to `}</p>
        <p>inner peace and healing</p>
      </div>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] min-w-full not-italic relative shrink-0 text-[#a7567b] text-[12px] w-[min-content]">At Shanti Path, you are invited to embark on a transformative journey back to yourself through the sacred practice of Tantra. This therapeutic approach utilizes sacred touch to awaken your energy and promote deep healing. By harmonizing your body, mind, and spirit, Tantra facilitates emotional release and profound relaxation, guiding you towards inner peace and holistic wellbeing.</p>
      <Frame29 />
      <Frame4 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex gap-[36px] items-center relative shrink-0">
      <Frame2 />
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <Wrapper6 additionalClassNames="h-[360px] w-[350px]">
            <img alt="" className="absolute h-[103.42%] left-[-27.41%] max-w-none top-[-1.78%] w-[159.54%]" src={imgRectangle1446} />
          </Wrapper6>
        </div>
      </div>
    </div>
  );
}

function Hero() {
  return (
    <div className="bg-[rgba(246,239,235,0)] content-stretch flex h-[428px] items-center justify-between pb-[8px] pt-[24px] px-[100px] relative shrink-0 w-[1440px]" data-name="hero">
      <Frame5 />
    </div>
  );
}

function Divider() {
  return (
    <div className="h-[98px] relative shrink-0 w-[1440px]" data-name="divider">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1440 98">
        <g id="divider">
          <g id="Union">
            <path clipRule="evenodd" d={svgPaths.p13a19e00} fill="var(--fill-0, #E7DED8)" fillRule="evenodd" />
            <path clipRule="evenodd" d={svgPaths.p23b76a00} fill="var(--fill-0, #E7DED8)" fillRule="evenodd" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0 w-full">
      <TagText text="Begin Your Journey" />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#372420] text-[40px] text-center text-nowrap">How It Works</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#a7567b] text-[12px] text-center text-nowrap">{`Taking the first step toward healing requires courage. Here's what to expect on your journey with Shanti Path:`}</p>
    </div>
  );
}

function Title() {
  return (
    <div className="content-stretch flex flex-col items-center px-[100px] py-[8px] relative shrink-0 w-[1440px]" data-name="TITLE">
      <Frame6 />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-center flex flex-wrap gap-0 items-center justify-center relative shrink-0">
      <Text2 text="1" additionalClassNames="px-0 py-[8px]" />
      <Wrapper9 additionalClassNames="h-[0.573px] w-[199.999px]">
        <Wrapper additionalClassNames="rotate-[0.164deg]">
          <path d="M0 2.5H200" id="Vector 15" stroke="var(--stroke-0, #73374C)" strokeWidth="5" />
        </Wrapper>
      </Wrapper9>
      <Text2 text="2" additionalClassNames="p-[8px]" />
      <Frame48095459Helper />
      <Text2 text="3" additionalClassNames="px-0 py-[8px]" />
      <Frame48095459Helper />
      <Text2 text="4" additionalClassNames="px-0 py-[8px]" />
    </div>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start justify-center leading-[normal] not-italic relative self-stretch shrink-0 text-[#372420] text-center w-[200px]">
      <p className="font-['Inter:Medium',sans-serif] font-medium relative shrink-0 text-[14px] w-full">{`Your Session Experience `}</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal relative shrink-0 text-[12px] w-full">Experience the transformative power of your chosen therapy session in a safe and nurturing environment. Feel deep relaxation, that allows you to reconnect to your true self.</p>
    </div>
  );
}

function Frame14() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start justify-center not-italic relative self-stretch shrink-0 text-[#372420] text-center w-[200px]">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] relative shrink-0 text-[14px] w-full">Next Steps</p>
      <div className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] relative shrink-0 text-[12px] w-full">
        <p className="mb-0">After your session, we will discuss your experience and any insights gained. Together, we can determine the best path forward for your continued therapy and transformation.</p>
        <p>&nbsp;</p>
      </div>
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0">
      <Helper text="Book an initial interview" text1="Start by scheduling an initial paid interview. This is your opportunity to share your intentions and any concerns you may have. Together, we will create a plan for your individual therapeutic path." />
      <Helper text="Schedule Your First Session" text1="Once we’ve established a connection, you can book your first therapy session. Choose a day for your first therapy session that is not fully planned and allows you to stay relaxed after the session." />
      <Frame13 />
      <Frame14 />
    </div>
  );
}

function Frame7() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0 w-full">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#372420] text-[20px] text-nowrap">How it works</p>
      <Frame12 />
      <Frame11 />
    </div>
  );
}

function Content() {
  return (
    <Wrapper1 additionalClassNames="bg-[rgba(246,239,235,0)]">
      <Frame7 />
    </Wrapper1>
  );
}

function Section() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] h-[374px] items-start relative shrink-0 w-full" data-name="SECTION">
      <Title />
      <Content />
    </div>
  );
}

function Divider1() {
  return (
    <div className="h-[100px] relative shrink-0 w-[1440px]" data-name="divider">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1440 100">
        <g id="divider">
          <g id="Union">
            <path d={svgPaths.p27955580} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p391bc970} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3fc77b80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pa24f500} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p340ed100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p28970b00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3dc90a00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p39cf7000} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p4198300} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p28291c80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2f88e700} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3913d500} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3e4ad900} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p13457700} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p21b1a970} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2478e000} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p41c2b80} fill="var(--fill-0, #E7DED8)" />
            <path clipRule="evenodd" d={svgPaths.p2c4c5870} fill="var(--fill-0, #E7DED8)" fillRule="evenodd" />
            <path d={svgPaths.p11ccb80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p358fa780} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pbf58f80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pd6ada80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p317ba400} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3c35f500} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3632c100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2b1c9c00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2be0dd00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p147aee00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2d324c70} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pc083880} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pbddf8b0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p516b000} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p10ef1f00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p17e70d00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p11171f80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p64b5380} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p235eb080} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p28aaba00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p104d7f00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p25748e00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p376d7140} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p11c87680} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p28856000} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p19d88d90} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p17592c00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p9c84c00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2933c780} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p366e0f80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3aa3800} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2b6c600} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1770f900} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1d8ae500} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3e41a300} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2a6cb100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p378fea00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p39caee00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p33368980} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1a38d500} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1cda9900} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p21f13c80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3a5db980} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p21eb3680} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2df42500} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3ff64100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p142b4500} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p23962280} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p17552900} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p29a26900} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pedd0400} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p33af480} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.paedc840} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3787ba00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p23180cf0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2f3a1c70} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pb3fbf80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pcd1e100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p359c2f00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1aa81880} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pb1e85a0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pf998600} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p20ccac00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p29d9bb00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p14b35b80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3420c170} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2c58ab40} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2793380} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p24a9180} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3fc7f780} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p42d8580} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1da3e800} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1ac00700} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p366e4300} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p26ea0680} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3efacc0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3d87b280} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3e277b00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p4162400} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1cecd900} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2d6e3a80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p284e5700} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pb184200} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1a376080} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2a743b0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p175a6f80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1a4dd300} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2f822180} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p30f5a400} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p25794900} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2bd95f00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p36d72f00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1e00600} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p144a0e00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p310bbd70} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3c255d80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p299b7170} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p445de00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p23ee7500} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p280e2280} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p316ff80} fill="var(--fill-0, #E7DED8)" />
            <path d="M738.842 79.078V79.078Z" fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2baad280} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p15c5885} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p6d3fd00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1e347280} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p234cf300} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2e1d5e00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p6326480} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p36bb9100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p357a1700} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p27abaa00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p36a17120} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1ffbc200} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p39202900} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.peb5bd00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p13aae680} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pf605d40} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2222b180} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3ea46580} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3a13aa70} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2a7cf780} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p35830d70} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pe609c00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p122e5c00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p4d0f540} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3dc07880} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3e0c2b00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2ee65100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p15482a00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2ce92e00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3438a200} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3c69d00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p37411280} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3259f400} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p35d05400} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p184a9b00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3ea1300} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3d1ae280} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p38f32900} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3191db00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1853c800} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p15ac8900} fill="var(--fill-0, #E7DED8)" />
            <path d="M689.395 68.662V68.662Z" fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3a2f3e00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2d182d80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1928c00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pd7f8740} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p363085f0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p72bd880} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.peca8e00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p30ed0300} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p9fa9e00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p185cab00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p219f4900} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p20459d00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pf807300} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p23062680} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2f384fb0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p319cbe00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p16d31800} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2908e770} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p174b7700} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1c5ab100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1fb56880} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p396a5b00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1eab2c40} fill="var(--fill-0, #E7DED8)" />
            <path clipRule="evenodd" d={svgPaths.p3d5af000} fill="var(--fill-0, #E7DED8)" fillRule="evenodd" />
            <path d={svgPaths.p1ba50671} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2154f500} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pda32600} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3c55200} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p33eff300} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p242bab70} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3b8df600} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pc5ced00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pb54c880} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p193766f0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pae9dc00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p29392a80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p257c6a80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p7aabd80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1c028400} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p37329b00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1542a200} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pbf5cda0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p39ebb500} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p190d5580} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p11149ff0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p4e8d040} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pd222b80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p7223580} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pef30e80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p349cb480} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1e187500} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pe91b480} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p9d3d600} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p35d70cf0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p287d3000} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3617ad40} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2dcaa100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p28db6200} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p37dc5330} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p22cb5a80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pa023ff0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3cd84200} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3850e280} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2efa7c00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pe360000} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p30b44300} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p33c9c200} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3ba5ad80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p156bf440} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p39ecf100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p190d8480} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2d954680} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p106e5240} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3c4d9800} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p31951600} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pb79d800} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1d99cc80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pf2dcd00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p204c1200} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3d171c80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p9f06c00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p33aefa80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p5063a00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p10a28e80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p183d7cf0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p8743c80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p22182a00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p372606c0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2e116900} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p11b46e40} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pb106050} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p19836c00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p24339540} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3789ce80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p33969970} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p340d0600} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p111b4a00} fill="var(--fill-0, #E7DED8)" />
            <path clipRule="evenodd" d={svgPaths.p256ef500} fill="var(--fill-0, #E7DED8)" fillRule="evenodd" />
            <path d={svgPaths.p108ad300} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p20514e00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2fa7e400} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3713fd00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pc865100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3e371980} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2d1fe9c0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p34845600} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p4b4a280} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3668c900} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2d620340} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2c469200} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1f42ea00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2977a100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p13b9eb00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p371c9f80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p19f23900} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p296aca80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p8c65b80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pc13e980} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p151e7572} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2e92d9f0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pd10d00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3a973580} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pd743000} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1c935e00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pfdc2bf0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p29f6100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p178cf500} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p13af9040} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pc407000} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1d228380} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p65b9b80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2f589b00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3c7fb9f0} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2e94f600} fill="var(--fill-0, #E7DED8)" />
            <path d="M686.732 20.0321V20.0321Z" fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1d9c8300} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pa320100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p394d0380} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3da19000} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3950e000} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p16426100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p361f1b80} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pe753e00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2c135600} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p30f5d200} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p236ae480} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2747cc00} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1f1f3100} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p2dbee200} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p1069d480} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pe31e300} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p4a8c700} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p34f84800} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.pb065900} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p3973d700} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p193bd400} fill="var(--fill-0, #E7DED8)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Tag() {
  return <Wrapper5>{` Importance of the Interview`}</Wrapper5>;
}

function Frame8() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0 w-full">
      <Tag />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#372420] text-[40px] text-center text-nowrap">Why Tantra Needs An Interview</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#a7567b] text-[12px] text-center text-nowrap">The interview process is essential for ensuring a safe and personalized experience. Here’s why it matters</p>
    </div>
  );
}

function Title1() {
  return (
    <div className="content-stretch flex flex-col items-center px-[100px] py-[8px] relative shrink-0 w-[1440px]" data-name="TITLE">
      <Frame8 />
    </div>
  );
}

function StateLayer() {
  return (
    <div className="content-stretch flex h-[40px] items-center justify-center relative shrink-0 w-full" data-name="State-layer">
      <Icon />
    </div>
  );
}

function Content1() {
  return (
    <div className="bg-[#e7ded8] content-stretch flex flex-col items-center justify-center overflow-clip relative rounded-[100px] shrink-0 w-[40px]" data-name="Content">
      <StateLayer />
    </div>
  );
}

function IconButtonTogglable() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 size-[48px]" data-name="Icon button togglable">
      <Content1 />
      <Icon1 />
    </div>
  );
}

function Frame27() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start justify-center relative self-stretch shrink-0 w-[237px]">
      <IconButtonTogglable />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] min-w-full not-italic relative shrink-0 text-[#372420] text-[14px] w-[min-content]">{` 1. For Your Safety`}</p>
      <div className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] min-w-full not-italic relative shrink-0 text-[#372420] text-[12px] w-[min-content]">
        <p className="mb-0">Tantra massage works with the nervous system, intimate blockages, and deep emotions. The interview ensures that the process is suitable, safe, and appropriately tailored to your body and condition.</p>
        <p>&nbsp;</p>
      </div>
    </div>
  );
}

function StateLayer1() {
  return (
    <div className="content-stretch flex h-[40px] items-center justify-center relative shrink-0 w-full" data-name="State-layer">
      <Icon />
    </div>
  );
}

function Content2() {
  return (
    <div className="bg-[#e7ded8] content-stretch flex flex-col items-center justify-center overflow-clip relative rounded-[100px] shrink-0 w-[40px]" data-name="Content">
      <StateLayer1 />
    </div>
  );
}

function IconButtonTogglable1() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 size-[48px]" data-name="Icon button togglable">
      <Content2 />
      <Icon1 />
    </div>
  );
}

function Frame15() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start justify-center relative self-stretch shrink-0 w-[238px]">
      <IconButtonTogglable1 />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] min-w-full not-italic relative shrink-0 text-[#372420] text-[14px] w-[min-content]">2. For Trust and Clear Boundaries</p>
      <div className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] min-w-full not-italic relative shrink-0 text-[#372420] text-[12px] w-[min-content]">
        <p className="mb-0">{`Before entering such an intense practice, it's important to feel comfortable with the person guiding you. The interview establishes boundaries, rules, and clarity, allowing you to truly relax during the session.`}</p>
        <p>&nbsp;</p>
      </div>
    </div>
  );
}

function StateLayer2() {
  return (
    <div className="content-stretch flex h-[40px] items-center justify-center relative shrink-0 w-full" data-name="State-layer">
      <Icon />
    </div>
  );
}

function Content3() {
  return (
    <div className="bg-[#e7ded8] content-stretch flex flex-col items-center justify-center overflow-clip relative rounded-[100px] shrink-0 w-[40px]" data-name="Content">
      <StateLayer2 />
    </div>
  );
}

function IconButtonTogglable2() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 size-[48px]" data-name="Icon button togglable">
      <Content3 />
      <Icon1 />
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start justify-center relative self-stretch shrink-0 w-[237px]">
      <IconButtonTogglable2 />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] min-w-full not-italic relative shrink-0 text-[#372420] text-[14px] w-[min-content]">3. For an Individual Path</p>
      <div className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] min-w-full not-italic relative shrink-0 text-[#372420] text-[12px] w-[min-content]">
        <p className="mb-0">Your body has a story. The interview allows me to understand your needs and prepare a personalized approach, ensuring that even the first session works deeply.</p>
        <p>&nbsp;</p>
      </div>
    </div>
  );
}

function Frame33() {
  return (
    <div className="content-stretch flex items-start justify-between relative shrink-0 w-[844px]">
      <Frame27 />
      <Frame15 />
      <Frame16 />
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0 w-full">
      <Frame33 />
    </div>
  );
}

function Frame34() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start justify-center relative shrink-0">
      <Text text="Request an intervew" />
    </div>
  );
}

function Button1() {
  return (
    <div className="bg-[#a7567b] content-stretch flex flex-col gap-[8px] h-[48px] items-center justify-center overflow-clip px-[24px] py-[8px] relative rounded-[4px] shrink-0" data-name="Button 2">
      <div className="absolute bg-[#a7567b] inset-0 rounded-[7.2px]" data-name="Rectangle" />
      <Frame34 />
    </div>
  );
}

function Content4() {
  return (
    <Wrapper1 additionalClassNames="bg-[rgba(246,239,235,0)]">
      <Frame9 />
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] min-w-full not-italic relative shrink-0 text-[#372420] text-[12px] text-center w-[min-content]">{`Your healing journey begins with a 30-minute initial consultation (€30). `}</p>
      <Button1 />
    </Wrapper1>
  );
}

function Section1() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full" data-name="SECTION">
      <Title1 />
      <Content4 />
    </div>
  );
}

function GroupR() {
  return (
    <div className="h-[98px] relative shrink-0 w-[83.132px]" data-name="group-R5">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 83.1319 98">
        <g id="group-R5">
          <path d={svgPaths.p30085d80} fill="var(--fill-0, #E7DED8)" id="path228" />
          <path d={svgPaths.p25e725f0} fill="var(--fill-0, #E7DED8)" id="path233" />
          <path d={svgPaths.p11bc5200} fill="var(--fill-0, #E7DED8)" id="path234" />
          <path d={svgPaths.p39c36600} fill="var(--fill-0, #E7DED8)" id="path235" />
          <path d={svgPaths.pf5a6880} fill="var(--fill-0, #E7DED8)" id="path236" />
          <path d={svgPaths.p21beca40} fill="var(--fill-0, #E7DED8)" id="path237" />
          <path d={svgPaths.p18df9900} fill="var(--fill-0, #E7DED8)" id="path238" />
          <path d={svgPaths.p2b725400} fill="var(--fill-0, #E7DED8)" id="path239" />
          <path d={svgPaths.pc4ed700} fill="var(--fill-0, #E7DED8)" id="path240" />
          <path d={svgPaths.p26d92280} fill="var(--fill-0, #E7DED8)" id="path241" />
          <path d={svgPaths.p178fd280} fill="var(--fill-0, #E7DED8)" id="path242" />
          <path d={svgPaths.p70f600} fill="var(--fill-0, #E7DED8)" id="path243" />
          <path d={svgPaths.p2d8acc00} fill="var(--fill-0, #E7DED8)" id="path244" />
          <path d={svgPaths.p313e3000} fill="var(--fill-0, #E7DED8)" id="path245" />
          <path d={svgPaths.p20fe6880} fill="var(--fill-0, #E7DED8)" id="path246" />
          <path d={svgPaths.p1a79d880} fill="var(--fill-0, #E7DED8)" id="path247" />
          <path d={svgPaths.p329d0600} fill="var(--fill-0, #E7DED8)" id="path248" />
          <path d={svgPaths.p1bdb1c00} fill="var(--fill-0, #E7DED8)" id="path249" />
          <path d={svgPaths.p9c45780} fill="var(--fill-0, #E7DED8)" id="path250" />
          <path d={svgPaths.p32b3680} fill="var(--fill-0, #E7DED8)" id="path251" />
          <path d={svgPaths.p3af16d00} fill="var(--fill-0, #E7DED8)" id="path252" />
          <path d={svgPaths.p1878b900} fill="var(--fill-0, #E7DED8)" id="path253" />
          <path d={svgPaths.p3c411a00} fill="var(--fill-0, #E7DED8)" id="path254" />
          <path d={svgPaths.p3c2c2a00} fill="var(--fill-0, #E7DED8)" id="path255" />
          <path d={svgPaths.pae688c0} fill="var(--fill-0, #E7DED8)" id="path256" />
          <path d={svgPaths.p29920d80} fill="var(--fill-0, #E7DED8)" id="path257" />
          <path d={svgPaths.p170d3d00} fill="var(--fill-0, #E7DED8)" id="path258" />
          <path d={svgPaths.pc776400} fill="var(--fill-0, #E7DED8)" id="path259" />
          <path d={svgPaths.p1ab5ed00} fill="var(--fill-0, #E7DED8)" id="path260" />
          <path d={svgPaths.p46e0580} fill="var(--fill-0, #E7DED8)" id="path261" />
          <path d={svgPaths.p1d145100} fill="var(--fill-0, #E7DED8)" id="path262" />
          <path d={svgPaths.pc82c80} fill="var(--fill-0, #E7DED8)" id="path263" />
          <path d={svgPaths.p25926600} fill="var(--fill-0, #E7DED8)" id="path264" />
          <path d={svgPaths.p20c800} fill="var(--fill-0, #E7DED8)" id="path265" />
          <path d={svgPaths.p8eb0100} fill="var(--fill-0, #E7DED8)" id="path266" />
          <path d={svgPaths.p3670180} fill="var(--fill-0, #E7DED8)" id="path267" />
          <path d={svgPaths.p14585d00} fill="var(--fill-0, #E7DED8)" id="path268" />
          <path d={svgPaths.p68b8180} fill="var(--fill-0, #E7DED8)" id="path269" />
          <path d={svgPaths.p3a3725c0} fill="var(--fill-0, #E7DED8)" id="path270" />
          <path d={svgPaths.p1e821500} fill="var(--fill-0, #E7DED8)" id="path271" />
          <path d={svgPaths.pe6aa600} fill="var(--fill-0, #E7DED8)" id="path272" />
          <path d={svgPaths.pe600e00} fill="var(--fill-0, #E7DED8)" id="path273" />
          <path d={svgPaths.p36f97b00} fill="var(--fill-0, #E7DED8)" id="path274" />
          <path d={svgPaths.pe2fab00} fill="var(--fill-0, #E7DED8)" id="path275" />
          <path d={svgPaths.p1b701e00} fill="var(--fill-0, #E7DED8)" id="path276" />
          <path d={svgPaths.pdfb5000} fill="var(--fill-0, #E7DED8)" id="path277" />
          <path d={svgPaths.p12121c00} fill="var(--fill-0, #E7DED8)" id="path278" />
          <path d={svgPaths.pd58f600} fill="var(--fill-0, #E7DED8)" id="path279" />
          <path d={svgPaths.p36d48500} fill="var(--fill-0, #E7DED8)" id="path280" />
          <path d={svgPaths.p1bac400} fill="var(--fill-0, #E7DED8)" id="path281" />
          <path d={svgPaths.p1fd07280} fill="var(--fill-0, #E7DED8)" id="path282" />
          <path d={svgPaths.p3cd54500} fill="var(--fill-0, #E7DED8)" id="path283" />
          <path d={svgPaths.p3e4e6900} fill="var(--fill-0, #E7DED8)" id="path284" />
          <path d={svgPaths.pbde5200} fill="var(--fill-0, #E7DED8)" id="path285" />
          <path d={svgPaths.p187e8fe0} fill="var(--fill-0, #E7DED8)" id="path286" />
          <path d={svgPaths.p26b89380} fill="var(--fill-0, #E7DED8)" id="path287" />
          <path d={svgPaths.p1b7d4450} fill="var(--fill-0, #E7DED8)" id="path288" />
          <path d={svgPaths.p35a63000} fill="var(--fill-0, #E7DED8)" id="path289" />
        </g>
      </svg>
    </div>
  );
}

function Divider2() {
  return (
    <div className="content-stretch flex items-center justify-center px-[100px] py-0 relative shrink-0 w-[1440px]" data-name="divider">
      <GroupR />
    </div>
  );
}

function Frame35() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0 w-full">
      <TagText text="Sacred Offerings" />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#372420] text-[40px] text-center text-nowrap">Sacred Offerings for Your Healing Journey</p>
      <div className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#a7567b] text-[12px] text-center text-nowrap">
        <p className="mb-0">Each session at Shanti Path is a ceremony. I offer various pathways to support your unique needs</p>
        <p>and where you are on your healing journey.</p>
      </div>
    </div>
  );
}

function Title2() {
  return (
    <div className="content-stretch flex flex-col items-center px-[100px] py-[8px] relative shrink-0 w-[1440px]" data-name="TITLE">
      <Frame35 />
    </div>
  );
}

function Frame21() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start leading-[normal] not-italic relative shrink-0 w-full">
      <Helper1 text="Full Body Tantra Massage Journey" text1="Duration: 3 hours | Investment: €350" />
      <Helper2 />
    </div>
  );
}

function Frame36() {
  return <Wrapper4 additionalClassNames="size-[16px]">{`Deep chakra balancing and energy activation `}</Wrapper4>;
}

function Frame37() {
  return <Wrapper4>{`Release of physical, emotional, and energetic blockages `}</Wrapper4>;
}

function Frame17() {
  return <Wrapper4 additionalClassNames="size-[16px]">{`Integration of sexual energy throughout the body `}</Wrapper4>;
}

function Frame19() {
  return <Wrapper4>{`Closing meditation and integration (15 min) `}</Wrapper4>;
}

function Frame18() {
  return <Wrapper4>{`Grounding tea and gentle return to the world `}</Wrapper4>;
}

function Frame20() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0">
      <Text3 text="Opening consultation and intention-setting (15 min)" />
      <Text3 text="Grounding breathwork and meditation" />
      <Frame36 />
      <Frame37 />
      <Frame17 />
      <Helper3 />
      <Frame19 />
      <Frame18 />
    </div>
  );
}

function Frame22() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0">
      <p className="font-['Inter:Bold',sans-serif] font-bold leading-[normal] not-italic relative shrink-0 text-[#987b88] text-[#bfa190] text-[12px] w-[262px]">
        WHAT TO EXPEC<span className="tracking-[3.2px]">T</span>
      </p>
      <Frame20 />
    </div>
  );
}

function Frame23() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0">
      <Frame22 />
      <Wrapper9 additionalClassNames="h-[11.997px] w-[371px]">
        <div className="flex-none rotate-[359.073deg]">
          <div className="h-[5.999px] relative w-[370.951px]">
            <div className="absolute inset-[-8.33%_0]" style={{ "--stroke-0": "rgba(152, 123, 136, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 370.968 6.99908">
                <path d={svgPaths.p2c5134a0} id="Vector 17" stroke="var(--stroke-0, #987B88)" />
              </svg>
            </div>
          </div>
        </div>
      </Wrapper9>
      <Text4 text="Anyone seeking deep healing, those new to Tantra who want a complete experience, or experienced receivers ready for profound transformation." />
    </div>
  );
}

function Frame38() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full">
      <Frame21 />
      <Frame23 />
    </div>
  );
}

function Card() {
  return (
    <div className="bg-[#d3b5c3] content-stretch flex flex-col items-start justify-center px-[24px] py-[36px] relative rounded-[8px] shrink-0 w-[413px]" data-name="card">
      <div aria-hidden="true" className="absolute border border-[#73374c] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <Frame38 />
    </div>
  );
}

function Frame39() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start leading-[normal] not-italic relative shrink-0 w-full">
      <Helper1 text="Essential Tantra Massage" text1="Duration: 1.5 hours | Investment: €200" />
      <Helper2 />
    </div>
  );
}

function Frame40() {
  return <Wrapper4>{`Opening consultation and centering (10 min) `}</Wrapper4>;
}

function Frame41() {
  return <Wrapper4>{`Breathwork and energy preparation `}</Wrapper4>;
}

function Frame42() {
  return <Wrapper4 additionalClassNames="size-[16px]">{`Full-body massage with energy work `}</Wrapper4>;
}

function Frame43() {
  return <Wrapper4>{`Chakra activation and balancing `}</Wrapper4>;
}

function Frame44() {
  return <Wrapper4 additionalClassNames="size-[16px]">{`Release of key tension and blockages `}</Wrapper4>;
}

function Frame45() {
  return <Wrapper4>{`Integration and grounding `}</Wrapper4>;
}

function Frame46() {
  return <Wrapper4>{`Brief closing and reflection (10 min) `}</Wrapper4>;
}

function Frame47() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0">
      <Frame40 />
      <Frame41 />
      <Frame42 />
      <Frame43 />
      <Frame44 />
      <Helper3 />
      <Frame45 />
      <Frame46 />
    </div>
  );
}

function Frame48() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0">
      <p className="font-['Inter:Bold',sans-serif] font-bold leading-[normal] not-italic relative shrink-0 text-[#987b88] text-[#bfa190] text-[12px] w-[262px]">
        WHAT TO EXPEC<span className="tracking-[3.2px]">T</span>
      </p>
      <Frame47 />
    </div>
  );
}

function Frame49() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full">
      <Frame48 />
      <div className="h-0 relative shrink-0 w-[365px]">
        <div className="absolute inset-[-0.5px_0]" style={{ "--stroke-0": "rgba(152, 123, 136, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 365 1">
            <path d="M0 0.5H365" id="Vector 17" stroke="var(--stroke-0, #987B88)" />
          </svg>
        </div>
      </div>
      <Text4 text="Anyone seeking deep healing, those new to Tantra who want a complete experience, or experienced receivers ready for profound transformation." />
    </div>
  );
}

function Frame50() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-[365px]">
      <Frame39 />
      <Frame49 />
    </div>
  );
}

function Card1() {
  return (
    <div className="bg-[#e7ded8] content-stretch flex flex-col h-full items-start justify-center px-[24px] py-[36px] relative rounded-[8px] shrink-0" data-name="card">
      <Frame50 />
    </div>
  );
}

function Frame30() {
  return (
    <div className="content-stretch flex gap-[24px] h-[502.997px] items-center relative shrink-0">
      <Card />
      <Card1 />
    </div>
  );
}

function Frame51() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0">
      <Text1 text="Explore further offerings" />
    </div>
  );
}

function Button4() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[16px] py-[8px] relative rounded-[4px] shrink-0" data-name="Button 2">
      <Frame51 />
    </div>
  );
}

function Cards() {
  return (
    <Wrapper1>
      <Frame30 />
      <Button4 />
    </Wrapper1>
  );
}

function Section2() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full" data-name="SECTION">
      <Title2 />
      <Cards />
    </div>
  );
}

function Divider3() {
  return (
    <div className="h-[87px] relative shrink-0 w-[1440px]" data-name="divider">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1440 87">
        <g id="divider">
          <g id="Subtract">
            <path d={svgPaths.p3a389500} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p226ee900} fill="var(--fill-0, #E7DED8)" />
            <path d={svgPaths.p833b780} fill="var(--fill-0, #E7DED8)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Frame52() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0 w-full">
      <TagText text="Ancient Wisdom" />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#372420] text-[40px] text-center text-nowrap">The Transformative Power of Tantra</p>
      <div className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#a7567b] text-[12px] text-center text-nowrap">
        <p className="mb-0">{`Tantra Massage is a sacred, energy-based healing practice rooted in ancient wisdom. It is not merely touch a dance of energy `}</p>
        <p>{`that honors your body as a temple and recognizes every part of you as worthy of love and reverence. `}</p>
      </div>
    </div>
  );
}

function Title3() {
  return (
    <div className="content-stretch flex flex-col items-center px-[100px] py-[8px] relative shrink-0 w-[1440px]" data-name="TITLE">
      <Frame52 />
    </div>
  );
}

function Frame53() {
  return <Wrapper7>{`Releases energetic and emotional blockages that may have been held in your body for years `}</Wrapper7>;
}

function Frame54() {
  return (
    <div className="content-stretch flex gap-[24px] items-center relative shrink-0">
      <Helper4 />
      <Frame53 />
    </div>
  );
}

function Card2() {
  return (
    <Card11 additionalClassNames="bg-[#e4c5b3]">
      <Frame54 />
    </Card11>
  );
}

function Frame55() {
  return <Wrapper7>{`Awakens your vital life force, allowing it to flow freely through every cell `}</Wrapper7>;
}

function Frame56() {
  return (
    <div className="content-stretch flex gap-[24px] h-full items-center relative shrink-0">
      <Helper4 />
      <Frame55 />
    </div>
  );
}

function Card3() {
  return (
    <div className="basis-0 bg-[#d3b5c3] grow min-h-px min-w-px relative rounded-[8px] shrink-0 w-full" data-name="card">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center p-[16px] relative size-full">
          <Frame56 />
        </div>
      </div>
    </div>
  );
}

function Frame57() {
  return <Wrapper7>{`Balances your chakras and energy centers, restoring harmony to your being `}</Wrapper7>;
}

function Frame58() {
  return (
    <div className="content-stretch flex gap-[24px] items-center relative shrink-0">
      <Helper4 />
      <Frame57 />
    </div>
  );
}

function Card4() {
  return (
    <Card11 additionalClassNames="bg-[#e4c5b3]">
      <Frame58 />
    </Card11>
  );
}

function Frame59() {
  return <Wrapper7>{`Reconnects you with your sensual and spiritual self in a deeply healing way `}</Wrapper7>;
}

function Frame60() {
  return (
    <div className="content-stretch flex gap-[24px] items-center relative shrink-0">
      <Helper4 />
      <Frame59 />
    </div>
  );
}

function Card5() {
  return (
    <Card11 additionalClassNames="bg-[#d3b5c3]">
      <Frame60 />
    </Card11>
  );
}

function Frame61() {
  return <Wrapper7>{`Guides you toward wholeness, helping you remember the magnificent being you truly are `}</Wrapper7>;
}

function Frame62() {
  return (
    <div className="content-stretch flex gap-[24px] items-center relative shrink-0">
      <Helper4 />
      <Frame61 />
    </div>
  );
}

function Card6() {
  return (
    <Card11 additionalClassNames="bg-[#e4c5b3]">
      <Frame62 />
    </Card11>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] h-[441px] items-start relative shrink-0 w-[850px]">
      <Card2 />
      <Card3 />
      <Card4 />
      <Card5 />
      <Card6 />
    </div>
  );
}

function Frame63() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0">
      <Text1 text="Read more" />
    </div>
  );
}

function Button5() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[16px] py-[8px] relative rounded-[4px] shrink-0" data-name="Button 2">
      <Frame63 />
    </div>
  );
}

function Cards1() {
  return (
    <Wrapper1 additionalClassNames="bg-[rgba(246,239,235,0)]">
      <Frame10 />
      <Button5 />
    </Wrapper1>
  );
}

function Section3() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full" data-name="SECTION">
      <Title3 />
      <Cards1 />
    </div>
  );
}

function Frame64() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0 w-full">
      <TagText text="My Story" />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#372420] text-[40px] text-center text-nowrap">{`From Burnout to Healing `}</p>
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#a7567b] text-[12px] text-center text-nowrap">My Journey into spirituality</p>
    </div>
  );
}

function Title4() {
  return (
    <div className="content-stretch flex flex-col items-center px-[100px] py-[8px] relative shrink-0 w-[1440px]" data-name="TITLE">
      <Frame64 />
    </div>
  );
}

function Frame65() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0">
      <Text1 text="Read more" />
    </div>
  );
}

function Button6() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[16px] py-[8px] relative rounded-[4px] shrink-0" data-name="Button 2">
      <Frame65 />
    </div>
  );
}

function Frame66() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] h-[324px] items-center px-[36px] py-[8px] relative shrink-0 w-[552px]">
      <div className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] min-w-full not-italic relative shrink-0 text-[#372420] text-[12px] w-[min-content]">
        <p className="mb-0">{`A few years ago, I was completely burned out. Work consumed everything—I couldn't sleep, had no personal life, and my days blurred into an endless cycle of just getting through. I knew something had to change. This couldn't be all there was to life. `}</p>
        <p className="mb-0">&nbsp;</p>
        <p className="mb-0">{`That's when I discovered Tantra Yoga. I started practicing, and slowly, things began to shift. Through the breathwork, the energy practices, and eventually Tantra massage, I found my way back to myself. My body started to heal, sleep returned, and I reconnected with a sense of aliveness I'd forgotten existed. `}</p>
        <p className="mb-0">&nbsp;</p>
        <p className="mb-0">{`After experiencing this profound healing in my own life, I felt called to share it with others. I trained, deepened my practice, and now I'm here—offering this same path of healing through Shanti Path. `}</p>
        <p>{`If you're feeling lost, exhausted, or disconnected, I understand. And I'm here to guide you back home to yourself. `}</p>
      </div>
      <Button6 />
    </div>
  );
}

function Frame67() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[846px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <Wrapper6 additionalClassNames="h-[338px] w-[282px]">
            <img alt="" className="absolute h-[110.15%] left-[0.4%] max-w-none top-[-8.02%] w-[99.02%]" src={imgRectangle1447} />
          </Wrapper6>
        </div>
      </div>
      <Frame66 />
    </div>
  );
}

function Content5() {
  return (
    <div className="bg-[rgba(246,239,235,0)] relative shrink-0 w-full" data-name="content">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between pb-[8px] pt-[24px] px-[100px] relative w-full">
          <Frame67 />
        </div>
      </div>
    </div>
  );
}

function Section4() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full" data-name="SECTION">
      <Title4 />
      <Content5 />
    </div>
  );
}

function Frame68() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0 w-full">
      <TagText text="what you need to know" />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#372420] text-[40px] text-center text-nowrap">{`F&Q`}</p>
      <div className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#a7567b] text-[12px] text-center text-nowrap">
        <p className="mb-0">Each session at Shanti Path is a ceremony. I offer various pathways to support your unique needs</p>
        <p>and where you are on your healing journey. any other ask your ai.</p>
      </div>
    </div>
  );
}

function Title5() {
  return (
    <div className="content-stretch flex flex-col items-center px-[100px] py-[8px] relative shrink-0 w-[1440px]" data-name="TITLE">
      <Frame68 />
    </div>
  );
}

function Frame24() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full">
      <p className="basis-0 font-['Inter:Medium',sans-serif] font-medium grow leading-[normal] min-h-px min-w-px not-italic relative shrink-0 text-[#372420] text-[16px]">Is Tantra Massage sexual?</p>
      <Helper5 />
    </div>
  );
}

function Card7() {
  return (
    <div className="bg-white content-stretch flex flex-col h-[152px] items-start p-[16px] relative rounded-[8px] shrink-0 w-[850px]" data-name="card">
      <div aria-hidden="true" className="absolute border-2 border-[#e7ded8] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <Frame24 />
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] not-italic relative shrink-0 text-[#372420] text-[16px] w-full">No. While Tantra honors sexuality as sacred, this work is therapeutic and healing-focused. The intention is to restore wholeness, release blockages, and reconnect you with your vital energy—not sexual gratification.</p>
    </div>
  );
}

function Card8() {
  return <Wrapper3>{`I've experienced trauma. Is this safe for me?`}</Wrapper3>;
}

function Frame69() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0">
      <Text1 text="Read more" />
    </div>
  );
}

function Button7() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[16px] py-[8px] relative rounded-[4px] shrink-0" data-name="Button 2">
      <Frame69 />
    </div>
  );
}

function Content6() {
  return (
    <div className="bg-[rgba(246,239,235,0)] relative shrink-0 w-full" data-name="content">
      <div className="flex flex-col items-center size-full">
        <div className="content-stretch flex flex-col gap-[8px] items-center px-[100px] py-[8px] relative w-full">
          <Card7 />
          <Text5 text="What should I wear?" />
          <Text5 text="Do I need to book a consultation first?" />
          <Text5 text="Should I choose the 1.5-hour or 3-hour session?" />
          <Card8 />
          <Text5 text="Do you work with men/women/couples?" />
          <Text5 text="What about the packages—how do they work?" />
          <Text5 text="What if I feel emotional during the session?" />
          <Button7 />
        </div>
      </div>
    </div>
  );
}

function Section5() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full" data-name="SECTION">
      <Title5 />
      <Content6 />
    </div>
  );
}

function Frame70() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0 w-full">
      <TagText text="what people say" />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#372420] text-[40px] text-center text-nowrap">Reviews</p>
      <div className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#a7567b] text-[12px] text-center text-nowrap">
        <p className="mb-0">Each session at Shanti Path is a ceremony. I offer various pathways to support your unique needs</p>
        <p>and where you are on your healing journey.</p>
      </div>
    </div>
  );
}

function Title6() {
  return (
    <div className="content-stretch flex flex-col items-center px-[100px] py-[8px] relative shrink-0 w-[1440px]" data-name="TITLE">
      <Frame70 />
    </div>
  );
}

function Frame71() {
  return (
    <Wrapper8>
      <span>{`“This was amazing, This is great I have never experience and care created such are great experience and it was amazing and she is the best. The therapist was very gentle” `}</span>
      <span className="text-[#a7567b]">more...</span>
    </Wrapper8>
  );
}

function Frame72() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full">
      <Frame71 />
    </div>
  );
}

function Card9() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start justify-center px-[24px] py-[36px] relative rounded-[8px] shrink-0 w-[195px]" data-name="card">
      <Frame72 />
    </div>
  );
}

function Frame73() {
  return <Wrapper8>“This was amazing, This is great I have never experience and care created such are great experience and it was amazing and she is the best. The therapist was very gentle”</Wrapper8>;
}

function Frame74() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full">
      <Frame73 />
    </div>
  );
}

function Card10() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start justify-center px-[24px] py-[36px] relative rounded-[8px] shrink-0 w-[195px]" data-name="card">
      <Frame74 />
    </div>
  );
}

function COntent() {
  return (
    <div className="bg-[rgba(246,239,235,0)] relative shrink-0 w-full" data-name="COntent">
      <div className="flex flex-row justify-center size-full">
        <div className="content-stretch flex gap-[24px] items-start justify-center pb-[8px] pt-[24px] px-[100px] relative w-full">
          <Card9 />
          {[...Array(3).keys()].map((_, i) => (
            <Card10 key={i} />
          ))}
        </div>
      </div>
    </div>
  );
}

function Section6() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full" data-name="SECTION">
      <Title6 />
      <COntent />
    </div>
  );
}

function Tag1() {
  return (
    <div className="bg-[#372420] content-stretch flex items-center justify-center px-[8px] py-[4px] relative shrink-0" data-name="Tag">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[normal] not-italic relative shrink-0 text-[#e7ded8] text-[11px] text-center text-nowrap tracking-[2px] uppercase">Your Journey</p>
    </div>
  );
}

function Frame75() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[100px] items-center justify-center relative shrink-0 w-full">
      <Tag1 />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[normal] not-italic relative shrink-0 text-[#e7ded8] text-[40px] text-center text-nowrap">Begin your journey to wholeness</p>
      <p className="basis-0 font-['Inter:Medium','Noto_Sans:Medium',sans-serif] font-medium grow leading-[normal] min-h-px min-w-px not-italic relative shrink-0 text-[#372420] text-[12px] text-center w-[485px]">The journey of a thousand miles begins with a single step. Your path to peace, wholeness, and awakening is calling. I look forward to walking beside you.</p>
    </div>
  );
}

function Title7() {
  return (
    <div className="content-stretch flex flex-col items-center px-[100px] py-[8px] relative shrink-0 w-[1440px]" data-name="TITLE">
      <Frame75 />
    </div>
  );
}

function Frame76() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0">
      <p className="font-['Inter:Bold',sans-serif] font-bold leading-[28.8px] not-italic relative shrink-0 text-[#a7567b] text-[14px] text-nowrap">Request an interview</p>
    </div>
  );
}

function Frame77() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start justify-center relative shrink-0">
      <Frame76 />
    </div>
  );
}

function Button8() {
  return (
    <div className="bg-[#e7ded8] content-stretch flex flex-col gap-[8px] h-[48px] items-center justify-center overflow-clip px-[24px] py-[8px] relative rounded-[4px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] shrink-0" data-name="Button 1">
      <div className="absolute bg-[#e7ded8] inset-0 rounded-[7.2px]" data-name="Rectangle" />
      <Frame77 />
    </div>
  );
}

function Frame78() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0">
      <Text7 text="Tantra Path" />
    </div>
  );
}

function Button9() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[16px] py-[8px] relative rounded-[4px] shrink-0" data-name="Button 1">
      <Frame78 />
    </div>
  );
}

function Frame79() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0">
      <Text7 text="Reiki Path" />
    </div>
  );
}

function Button10() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[16px] py-[8px] relative rounded-[4px] shrink-0" data-name="Button 2">
      <Frame79 />
    </div>
  );
}

function Frame80() {
  return <Wrapper2>{`My Offerings `}</Wrapper2>;
}

function Frame81() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0">
      <Frame80 />
    </div>
  );
}

function Button11() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[16px] py-[8px] relative rounded-[4px] shrink-0" data-name="Button 3">
      <Frame81 />
    </div>
  );
}

function Frame26() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0">
      <Button9 />
      <Button10 />
      <Button11 />
    </div>
  );
}

function Frame82() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0">
      <Text7 text="About Me" />
    </div>
  );
}

function Button12() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[16px] py-[8px] relative rounded-[4px] shrink-0" data-name="Button 1">
      <Frame82 />
    </div>
  );
}

function Frame83() {
  return <Wrapper2>{`F&Q`}</Wrapper2>;
}

function Frame84() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0">
      <Frame83 />
    </div>
  );
}

function Button13() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[16px] py-[8px] relative rounded-[4px] shrink-0" data-name="Button 2">
      <Frame84 />
    </div>
  );
}

function Frame85() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0">
      <Text7 text="Contact" />
    </div>
  );
}

function Button14() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[16px] py-[8px] relative rounded-[4px] shrink-0" data-name="Button 3">
      <Frame85 />
    </div>
  );
}

function Frame86() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0">
      <Button12 />
      <Button13 />
      <Button14 />
    </div>
  );
}

function Frame25() {
  return (
    <div className="content-stretch flex gap-[36px] items-start relative shrink-0">
      <Frame26 />
      <Frame86 />
    </div>
  );
}

function Frame87() {
  return (
    <div className="content-stretch flex font-['Inter:Light',sans-serif] font-light gap-[36px] items-start leading-[28.8px] not-italic relative shrink-0 text-[16px] text-center text-nowrap text-white tracking-[-0.54px]">
      <p className="relative shrink-0">Socials</p>
      <p className="relative shrink-0">Socials</p>
      <p className="relative shrink-0">Socials</p>
    </div>
  );
}

function Frame88() {
  return (
    <div className="content-stretch flex flex-col gap-[36px] items-center justify-center relative shrink-0 w-full">
      <Button8 />
      <Frame25 />
      <div className="h-[87px] relative shrink-0 w-[99px]" data-name="Subtract">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 99 87">
          <g id="Subtract">
            <path d={svgPaths.p39737a00} fill="var(--fill-0, #BFA190)" fillOpacity="0.25" />
            <path d={svgPaths.p36f3900} fill="var(--fill-0, #BFA190)" fillOpacity="0.25" />
            <path d={svgPaths.pae551f2} fill="var(--fill-0, #BFA190)" fillOpacity="0.25" />
          </g>
        </svg>
      </div>
      <Frame87 />
    </div>
  );
}

function Footer() {
  return (
    <div className="bg-[#954f6f] content-stretch flex flex-col gap-[24px] items-center p-[100px] relative shrink-0 w-[1440px]" data-name="footer">
      <Title7 />
      <Frame88 />
      <div className="absolute inset-0 pointer-events-none shadow-[inset_0px_50px_100px_0px_rgba(115,55,76,0.85)]" />
    </div>
  );
}

function Body() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] items-start left-0 top-0 w-[1440px]" data-name="Body">
      <Navigation />
      <Hero />
      <Divider />
      <Section />
      <Divider1 />
      <Section1 />
      <Divider2 />
      <Section2 />
      <Divider3 />
      <Section3 />
      <Divider />
      <Section4 />
      <Divider1 />
      <Section5 />
      <Divider2 />
      <Section6 />
      <Divider />
      <Footer />
    </div>
  );
}

export default function V() {
  return (
    <div className="bg-[#f6efeb] relative size-full" data-name="V1">
      <BsckgroundVector />
      <Body />
    </div>
  );
}